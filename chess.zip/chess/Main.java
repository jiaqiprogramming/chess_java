import java.util.Scanner;

/**
 * Main class
 * @author @author Tingcheng Pan
 */
public class Main {

    /**
     * program execution function
     * @param args args
     */
    public static void main(String[] args) {
        Chessboard chessboard = new Chessboard();
        chessboard.drawChessboard();
        Scanner scanner = new Scanner(System.in);
        String winPlayer = "";
        while (true) {
            if (chessboard.isWhiteGo()) {
                System.out.print("White's move: ");
            } else {
                System.out.print("Black's move: ");
            }
            String value = scanner.nextLine().trim();
            if ("resign".equals(value.trim())) {
                winPlayer = chessboard.isWhiteGo() ? "Black" : "White";
                break;
            }
            String[] values = value.split(" ");
            if (values.length >= 3 && values[2].startsWith("draw")) {
                break;
            }
            String upgrade = null;
            if (values.length >= 3) {
                upgrade = values[2];
            }
            if (!chessboard.movePiece(values[0], values[1], upgrade)) {
                System.out.println("Illegal move, try again");
                continue;
            }
            if (!chessboard.checkKingExists()) {
                winPlayer = chessboard.isWhiteGo() ? "White" : "Black";
                break;
            } else if (chessboard.isCheckmate()) {
                System.out.println("Checkmate");
                winPlayer = chessboard.isWhiteGo() ? "White" : "Black";
                break;
            } else if (chessboard.isCheck()) {
                System.out.println("Check");
            }
            chessboard.nextGo();
            System.out.println("");
            chessboard.drawChessboard();
        }
        if (winPlayer.equals("")) {
            System.out.println("draw");
        } else {
            System.out.println(winPlayer + " wins");
        }
    }

}
