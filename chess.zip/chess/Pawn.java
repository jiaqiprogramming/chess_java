import java.util.Map;

/**
 * pawn piece
 * @author Tingcheng Pan
 */
public class Pawn extends Piece {

    /**
     * constructor
     * @param camp chess's camp
     * @param x the horizontal axis location
     * @param y the vertical axis location
     */
    public Pawn(String camp, int x, int y) {
        super(camp, "P", x, y);
    }

    @Override
    boolean canMove(int moveToX, int moveToY, Map<String, Piece> pieceMap) {
        Piece piece = pieceMap.get(moveToX + "_" + moveToY);
        if (camp.equals(Chessboard.CAMP_WHITE)) {
            if (y + 1 == moveToY && x == moveToX) {
                return piece == null;
            } else if (y + 1 == moveToY && x + 1 == moveToX) {
                return piece != null && !piece.camp.equals(this.camp);
            } else if (y + 1 == moveToY && x - 1 == moveToX) {
                return piece != null && !piece.camp.equals(this.camp);
            } else if (y + 2 == moveToY && x == moveToX && step == 0) {
                Piece p1 = pieceMap.get(moveToX + "_" + (y + 1));
                return p1 == null && piece == null;
            } else {
                return false;
            }
        } else {
            if (y - 1 == moveToY && x == moveToX) {
                return piece == null;
            } else if (y - 1 == moveToY && x + 1 == moveToX) {
                return !piece.camp.equals(this.camp);
            } else if (y - 1 == moveToY && x - 1 == moveToX) {
                return !piece.camp.equals(this.camp);
            } else if (y - 2 == moveToY && x == moveToX && step == 0) {
                Piece p1 = pieceMap.get(moveToX + "_" + (y - 1));
                return p1 == null && piece == null;
            } else {
                return false;
            }
        }
    }

    @Override
    public boolean canEat(int eatX, int eatY, Map<String, Piece> pieceMap) {
        if (camp.equals(Chessboard.CAMP_WHITE)) {
            if (Math.abs(eatX - this.x) == 1 && this.y + 1 == eatY) {
                return true;
            }
        } else {
            if (Math.abs(eatX - this.x) == 1 && this.y - 1 == eatY) {
                return true;
            }
        }
        return false;
    }

    public Piece upgrade(String type) {
        Piece piece;
        if ("R".equals(type)) {
            piece = new Rook(this.camp, this.x, this.y);
        } else if ("N".equals(type)) {
            piece = new Knight(this.camp, this.x, this.y);
        } else if ("B".equals(type)) {
            piece = new Bishop(this.camp, this.x, this.y);
        } else {
           piece = new Queen(this.camp, this.x, this.y);
        }
        piece.beginX = this.beginX;
        piece.beginY = this.beginY;
        piece.step = this.step;
        return piece;
    }
}
