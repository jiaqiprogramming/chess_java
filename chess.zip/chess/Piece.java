import java.util.List;
import java.util.Map;

/**
 * piece abstract class
 * @author Tingcheng Pan
 */
public abstract class Piece {

    /**
     * chess's camp
     */
    public String camp;
    /**
     * chess's type
     */
    public String type;
    /**
     * begin x value
     */
    public int beginX;
    /**
     * begin y value
     */
    public int beginY;
    /**
     * the horizontal axis location
     */
    public int x;

    /**
     * the vertical axis location
     */
    public int y;

    /**
     * piece go step number
     */
    public int step;

    /**
     * constructor
     * @param camp chess's camp
     * @param type chess's type
     * @param x the horizontal axis location
     * @param y the vertical axis location
     */
    public Piece(String camp, String type, int x, int y) {
        this.camp = camp;
        this.type = type;
        this.beginX = x;
        this.beginY = y;
        this.x = x;
        this.y = y;
        this.step = 0;
    }

    /**
     * abstract method piece can move
     * @param moveToX move to x value
     * @param moveToY move to y value
     * @param pieceMap piece map collection
     * @return true: can move; false: can not move
     */
    abstract boolean canMove(int moveToX, int moveToY, Map<String, Piece> pieceMap);

    /**
     * check if the pieces can be eaten
     * @param eatX x value
     * @param eatY y value
     * @param pieceMap piece map collection
     * @return  true: can eat; false cannot eat
     */
    public boolean canEat(int eatX, int eatY, Map<String, Piece> pieceMap) {
        if (canMove(eatX, eatY, pieceMap)) {
            return true;
        }
        return false;
    }

    /**
     * upgrade if need
     * @param type upgrade type
     * @return piece object
     */
    public Piece upgrade(String type) {
        return this;
    }

    @Override
    public String toString() {
        return this.camp + this.type;
    }

}
