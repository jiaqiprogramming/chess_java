import java.util.List;
import java.util.Map;

/**
 * bishop piece
 * @author Tingcheng Pan
 */
public class Bishop extends Piece {

    /**
     * constructor
     * @param camp chess's camp
     * @param x the horizontal axis location
     * @param y the vertical axis location
     */
    public Bishop(String camp, int x, int y) {
        super(camp, "B", x, y);
    }

    @Override
    boolean canMove(int moveToX, int moveToY, Map<String, Piece> pieceMap) {
        if (Math.abs(moveToX - x) != Math.abs(moveToY - y)) {
            return false;
        }
        if (moveToX > x && moveToY > y) {
            for (int i = 1; i <= Math.abs(moveToX - x); i++) {
                int endX = x + i;
                int endY = y + i;
                Piece piece = pieceMap.get(endX + "_" + endY);
                if (piece == null) {
                    continue;
                }
                if (endX == moveToX && endY == moveToY && !camp.equals(piece.camp)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (moveToX > x && moveToY < y) {
            for (int i = 1; i <= Math.abs(moveToX - x); i++) {
                int endX = x + i;
                int endY = y - i;
                Piece piece = pieceMap.get(endX + "_" + endY);
                if (piece == null) {
                    continue;
                }
                if (endX == moveToX && endY == moveToY && !camp.equals(piece.camp)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (moveToX < x && moveToY < y) {
            for (int i = 1; i <= Math.abs(moveToX - x); i++) {
                int endX = x - i;
                int endY = y - i;
                Piece piece = pieceMap.get(endX + "_" + endY);
                if (piece == null) {
                    continue;
                }
                if (endX == moveToX && endY == moveToY && !camp.equals(piece.camp)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (moveToX < x && moveToY > y) {
            for (int i = 1; i <= Math.abs(moveToX - x); i++) {
                int endX = x - i;
                int endY = y + i;
                Piece piece = pieceMap.get(endX + "_" + endY);
                if (piece == null) {
                    continue;
                }
                if (endX == moveToX && endY == moveToY && !camp.equals(piece.camp)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return true;
    }
}
