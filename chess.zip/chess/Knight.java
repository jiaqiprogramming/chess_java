import java.util.Map;

/**
 * knight piece
 * @author Tingcheng Pan
 */
public class Knight extends Piece{

    /**
     * constructor
     * @param camp chess's camp
     * @param x the horizontal axis location
     * @param y the vertical axis location
     */
    public Knight(String camp, int x, int y) {
        super(camp, "N", x, y);
    }

    @Override
    boolean canMove(int moveToX, int moveToY, Map<String, Piece> pieceMap) {
        Piece piece = pieceMap.get(moveToX + "_" + moveToY);
        if (piece != null && piece.camp.equals(this.camp)) {
            return false;
        }
        if (moveToX == this.x - 2 && moveToY == this.y - 1) {
            return true;
        } else if (moveToX == this.x + 2 && moveToY == this.y - 1) {
            return true;
        } else if (moveToX == this.x - 1 && moveToY == this.y - 2) {
            return true;
        } else if (moveToX == this.x + 1 && moveToY == this.y - 2) {
            return true;
        } else if (moveToX == this.x - 2 && moveToY == this.y + 1) {
            return true;
        } else if (moveToX == this.x + 2 && moveToY == this.y + 1) {
            return true;
        } else if (moveToX == this.x - 1 && moveToY == this.y + 2) {
            return true;
        } else if (moveToX == this.x + 1 && moveToY == this.y + 2) {
            return true;
        } else {
            return false;
        }
    }
}
