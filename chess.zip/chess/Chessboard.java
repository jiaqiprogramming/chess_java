import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * chessboard
 * @author Tingcheng Pan
 */
public class Chessboard {

    /**
     * black camp value
     */
    public final static String CAMP_BLACK = "b";

    /**
     * white camp value
     */
    public final static String CAMP_WHITE = "w";

    /**
     * piece list
     */
    private List<Piece> pieceList = new ArrayList<>();

    /**
     * piece map
     */
    private Map<String, Piece> pieceMap = new HashMap<>();

    /**
     * the black camp king piece
     */
    private Piece blackKing;

    /**
     * the white camp king piece
     */
    private Piece whiteKing;

    /**
     * is white player go
     * true: white player go;false:black player go
     */
    private boolean isWhiteGo = true;

    /**
     * constructor
     * create chess piece
     */
    public Chessboard() {
        pieceList.add(new Rook(CAMP_BLACK, 1, 8));
        pieceList.add(new Knight(CAMP_BLACK, 2, 8));
        pieceList.add(new Bishop(CAMP_BLACK, 3, 8));
        pieceList.add(new Queen(CAMP_BLACK, 4, 8));
        blackKing = new King(CAMP_BLACK, 5, 8);
        pieceList.add(blackKing);
        pieceList.add(new Bishop(CAMP_BLACK, 6, 8));
        pieceList.add(new Knight(CAMP_BLACK, 7, 8));
        pieceList.add(new Rook(CAMP_BLACK, 8, 8));
        pieceList.add(new Pawn(CAMP_BLACK, 1, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 2, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 3, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 4, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 5, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 6, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 7, 7));
        pieceList.add(new Pawn(CAMP_BLACK, 8, 7));

        pieceList.add(new Rook(CAMP_WHITE, 1, 1));
        pieceList.add(new Knight(CAMP_WHITE, 2, 1));
        pieceList.add(new Bishop(CAMP_WHITE, 3, 1));
        pieceList.add(new Queen(CAMP_WHITE, 4, 1));
        whiteKing = new King(CAMP_WHITE, 5, 1);
        pieceList.add(whiteKing);
        pieceList.add(new Bishop(CAMP_WHITE, 6, 1));
        pieceList.add(new Knight(CAMP_WHITE, 7, 1));
        pieceList.add(new Rook(CAMP_WHITE, 8, 1));
        pieceList.add(new Pawn(CAMP_WHITE, 1, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 2, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 3, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 4, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 5, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 6, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 7, 2));
        pieceList.add(new Pawn(CAMP_WHITE, 8, 2));

        for (Piece piece : pieceList) {
            pieceMap.put(piece.x + "_" + piece.y, piece);
        }
    }

    /**
     * move piece
     * @param begin begin string
     * @param end end string
     * @param upgrade pawn upgrade
     * @return true: can move;false:can not move
     */
    public boolean movePiece(String begin, String end, String upgrade) {
        int beginX = begin.charAt(0) - 'a' + 1;
        int beginY = begin.charAt(1) - '0';
        int endX = end.charAt(0) - 'a' + 1;
        int endY = end.charAt(1) - '0';
        String camp = isWhiteGo ? CAMP_WHITE : CAMP_BLACK;
        if (endX < 1 || endX > 8 || endY < 1 || endY > 8) {
            return false;
        }
        Piece piece = pieceMap.get(beginX + "_" + beginY);
        if (piece == null || !piece.camp.equals(camp)) {
            return false;
        }
        //Castling
        if (piece.type.equals("K") && piece.step == 0) {
            if (piece.camp.equals(CAMP_WHITE) && piece.x == 5 && piece.y == 1) {
                if (endX == 3 && endY == 1) {
                    Piece piece11 = pieceMap.get("1_1");
                    if (piece11 != null && piece11.step == 0) {
                        boolean haveOtherPiece = pieceMap.get("2_1") != null
                                || pieceMap.get("3_1") != null
                                || pieceMap.get("4_1") != null;
                        if (!haveOtherPiece) {
                            piece.x = endX;
                            piece.y = endY;
                            piece.step = piece.step + 1;
                            pieceMap.put(endX + "_" + endY, piece);
                            pieceMap.put(beginX + "_" + beginY, null);
                            piece11.x = 4;
                            piece11.y = 1;
                            piece11.step = piece11.step + 1;
                            pieceMap.put("4_1", piece11);
                            pieceMap.put("1_1", null);
                            return true;
                        }
                    }
                } else if (endX == 7 && endY == 1) {
                    Piece piece81 = pieceMap.get("8_1");
                    if (piece81 != null && piece81.step == 0) {
                        boolean haveOtherPiece = pieceMap.get("6_1") != null
                                || pieceMap.get("7_1") != null;
                        if (!haveOtherPiece) {
                            piece.x = endX;
                            piece.y = endY;
                            piece.step = piece.step + 1;
                            pieceMap.put(endX + "_" + endY, piece);
                            pieceMap.put(beginX + "_" + beginY, null);
                            piece81.x = 6;
                            piece81.y = 1;
                            piece81.step = piece81.step + 1;
                            pieceMap.put("6_1", piece81);
                            pieceMap.put("8_1", null);
                            return true;
                        }
                    }
                }
            }
            if (piece.camp.equals(CAMP_BLACK) && piece.x == 5 && piece.y == 8) {
                if (endX == 3 && endY == 8) {
                    Piece piece18 = pieceMap.get("1_8");
                    if (piece18 != null && piece18.step == 0) {
                        boolean haveOtherPiece = pieceMap.get("2_8") != null
                                || pieceMap.get("3_8") != null
                                || pieceMap.get("4_8") != null;
                        if (!haveOtherPiece) {
                            piece.x = endX;
                            piece.y = endY;
                            piece.step = piece.step + 1;
                            pieceMap.put(endX + "_" + endY, piece);
                            pieceMap.put(beginX + "_" + beginY, null);
                            piece18.x = 4;
                            piece18.y = 8;
                            piece18.step = piece18.step + 1;
                            pieceMap.put("4_8", piece18);
                            pieceMap.put("1_8", null);
                            return true;
                        }
                    }
                } else if (endX == 7 && endY == 8) {
                    Piece piece88 = pieceMap.get("8_8");
                    if (piece88 != null && piece88.step == 0) {
                        boolean haveOtherPiece = pieceMap.get("6_8") != null
                                || pieceMap.get("7_8") != null;
                        if (!haveOtherPiece) {
                            piece.x = endX;
                            piece.y = endY;
                            piece.step = piece.step + 1;
                            pieceMap.put(endX + "_" + endY, piece);
                            pieceMap.put(beginX + "_" + beginY, null);
                            piece88.x = 6;
                            piece88.y = 8;
                            piece88.step = piece88.step + 1;
                            pieceMap.put("6_8", piece88);
                            pieceMap.put("8_8", null);
                            return true;
                        }
                    }
                }
            }
        }
        //Enpassant
        boolean isEnpassant = false;
        if (piece.type.equals("P")
                && beginX != endX
                && pieceMap.get(endX + "_" + endY) == null
                && piece.canEat(endX, endY, pieceMap)) {
            Piece temp = null;
            if (isWhiteGo) {
                temp = pieceMap.get(endX + "_" + (endY - 1));
            } else {
                temp = pieceMap.get(endX + "_" + (endY + 1));
            }
            if (temp == null || temp.step > 1 || Math.abs(temp.beginY - temp.y) != 2) {
                return false;
            } else {
                pieceMap.put(temp.x + "_" + temp.y, null);
                isEnpassant = true;
            }
        }
        if (!isEnpassant && !piece.canMove(endX, endY, pieceMap)) {
            return false;
        }
        piece.x = endX;
        piece.y = endY;
        piece.step = piece.step + 1;
        //Promotion
        if (piece.type.equals("P")
                && ((isWhiteGo && piece.y == 8) || (!isWhiteGo && piece.y == 1))) {
            piece = piece.upgrade(upgrade);
        }
        pieceMap.put(endX + "_" + endY, piece);
        pieceMap.put(beginX + "_" + beginY, null);
        return true;
    }

    /**
     * the king whether exists
     * @return true: exists;false: not exists
     */
    public boolean checkKingExists() {
        if (isWhiteGo) {
            for (Piece piece : pieceMap.values()) {
                if (piece == null || piece.camp.equals(CAMP_WHITE)) {
                    continue;
                }
                if ("K".equals(piece.type)) {
                    return true;
                }
            }
        } else {
            for (Piece piece : pieceMap.values()) {
                if (piece == null || piece.camp.equals(CAMP_BLACK)) {
                    continue;
                }
                if ("K".equals(piece.type)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * the king is under check
     * @return true: check; false: not check
     */
    public boolean isCheck() {
        if (isWhiteGo) {
            for (Piece piece : pieceMap.values()) {
                if (piece == null || piece.camp.equals(CAMP_BLACK)) {
                    continue;
                }
                if (piece.canEat(blackKing.x, blackKing.y, pieceMap)) {
                    return true;
                }
            }
        } else {
            for (Piece piece : pieceMap.values()) {
                if (piece == null || piece.camp.equals(CAMP_WHITE)) {
                    continue;
                }
                if (piece.canEat(whiteKing.x, whiteKing.y, pieceMap)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * whether checkmate
     * @return true: checkmate; false not checkmate
     */
    public boolean isCheckmate() {
        if (isWhiteGo) {
            Piece beginPiece = null;
            for (Piece piece : pieceMap.values()) {
                if (piece != null && piece.camp.equals(CAMP_WHITE) && piece.canEat(blackKing.x, blackKing.y, pieceMap)) {
                    beginPiece = piece;
                    break;
                }
            }
            if (beginPiece == null) {
                return false;
            }
            for (Piece piece : pieceMap.values()) {
                if (piece != null && piece.camp.equals(CAMP_BLACK) && piece.canEat(beginPiece.x, beginPiece.y, pieceMap)) {
                    return false;
                }
            }
            Map<String, Piece> tempMap = new HashMap<>(pieceMap);
            for (int i = 1; i<=8; i++) {
                for (int j = 1; j <= 8; j++) {
                    if (pieceMap.get(i + "_" + j) != null) {
                        continue;
                    }
                    for (Piece piece : pieceMap.values()) {
                        if (piece == null || piece.camp.equals(CAMP_WHITE)
                                || (piece.x == blackKing.x && piece.y == blackKing.y)) {
                            continue;
                        }
                        if (piece.canMove(i, j, tempMap)) {
                            tempMap.put(piece.x + "_" + piece.y, null);
                            tempMap.put(i + "_" + j, piece);
                             if (!beginPiece.canEat(blackKing.x, blackKing.y, tempMap)) {
                                 return false;
                             }
                             tempMap.put(i + "_" + j, null);
                            tempMap.put(piece.x + "_" + piece.y, piece);
                        }
                    }
                }
            }
            for (int i = blackKing.x - 1; i <= blackKing.x + 1; i++) {
                for (int j = blackKing.y - 1; j <= blackKing.y + 1; j++) {
                    if (i < 1 || i > 8 || j < 1 || j > 8 || (blackKing.x == i && blackKing.y == j)) {
                        continue;
                    }
                    if (blackKing.canMove(i, j, pieceMap) && !this.canEat(CAMP_WHITE, i, j)) {
                        return false;
                    }
                }
            }
        } else {
            Piece beginPiece = null;
            for (Piece piece : pieceMap.values()) {
                if (piece != null && piece.camp.equals(CAMP_BLACK) && piece.canEat(whiteKing.x, whiteKing.y, pieceMap)) {
                    beginPiece = piece;
                    break;
                }
            }
            if (beginPiece == null) {
                return false;
            }
            for (Piece piece : pieceMap.values()) {
                if (piece != null && piece.camp.equals(CAMP_WHITE) && piece.canEat(beginPiece.x, beginPiece.y, pieceMap)) {
                    return false;
                }
            }
            Map<String, Piece> tempMap = new HashMap<>(pieceMap);
            for (int i = 1; i<=8; i++) {
                for (int j = 1; j <= 8; j++) {
                    if (pieceMap.get(i + "_" + j) != null) {
                        continue;
                    }
                    for (Piece piece : pieceMap.values()) {
                        if (piece == null || piece.camp.equals(CAMP_BLACK)
                                || (piece.x == whiteKing.x && piece.y == whiteKing.y)) {
                            continue;
                        }
                        if (piece.canMove(i, j, tempMap)) {
                            tempMap.put(piece.x + "_" + piece.y, null);
                            tempMap.put(i + "_" + j, piece);
                            if (!beginPiece.canEat(whiteKing.x, whiteKing.y, tempMap)) {
                                return false;
                            }
                            tempMap.put(i + "_" + j, null);
                            tempMap.put(piece.x + "_" + piece.y, piece);
                        }
                    }
                }
            }
            for (int i = whiteKing.x - 1; i <= whiteKing.x + 1; i++) {
                for (int j = whiteKing.y - 1; j <= whiteKing.y + 1; j++) {
                    if (i < 1 || i > 8 || j < 1 || j > 8 || (whiteKing.x == i && whiteKing.y == j)) {
                        continue;
                    }
                    if (whiteKing.canMove(i, j, pieceMap) && !this.canEat(CAMP_BLACK, i, j)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     * check camp piece can eat
     * @param camp camp
     * @param x x value
     * @param y y value
     * @return true:can eat; false: cannot eat
     */
    private boolean canEat(String camp, int x, int y) {
        for (Piece piece : pieceMap.values()) {
            if (piece == null || !piece.camp.equals(camp)) {
                continue;
            }
            if (piece.canEat(x, y, pieceMap)) {
                return true;
            }
        }
        return false;
    }

    /**
     * draw chessboard
     */
    public void drawChessboard() {
        for (int i = 8; i >= 0; i--) {
            for (int j = 1; j <= 9; j++) {
                if (i == 0) {
                    if (j < 9) {
                        char v = (char) ('a' + j - 1);
                        System.out.print(" " + v);
                    }
                } else if (j == 9) {
                    System.out.print(i);
                } else {
                    Piece piece = pieceMap.get(j + "_" + i);
                    if (piece != null) {
                        System.out.print(piece);
                    } else {
                        if ((i + j) % 2 == 0) {
                            System.out.print("##");
                        } else {
                            System.out.print("  ");
                        }
                    }
                }
                System.out.print(" ");
            }
            System.out.println("");
        }
        System.out.println("");
    }

    /**
     * whether white player go
     * @return true: white player go;false: black player go
     */
    public boolean isWhiteGo() {
        return isWhiteGo;
    }

    /**
     * change player go
     */
    public void nextGo() {
        this.isWhiteGo = !this.isWhiteGo;
    }

}
