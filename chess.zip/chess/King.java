import java.util.List;
import java.util.Map;

/**
 * king piece
 * @author Tingcheng Pan
 */
public class King extends Piece {

    /**
     * constructor
     * @param camp chess's camp
     * @param x the horizontal axis location
     * @param y the vertical axis location
     */
    public King(String camp, int x, int y) {
        super(camp, "K", x, y);
    }

    @Override
    boolean canMove(int moveToX, int moveToY, Map<String, Piece> pieceMap) {
        Piece exists = pieceMap.get(moveToX + "_" + moveToY);
        if (exists != null && this.camp.equals(exists.camp)) {
            return false;
        }
        if (this.x == moveToX && Math.abs(this.y - moveToY) == 1) {
            return true;
        }
        if (this.y == moveToY && Math.abs(this.x - moveToX) == 1) {
            return true;
        }
        if (Math.abs(this.x - moveToX) == 1 && Math.abs(this.y - moveToY) == 1) {
            return true;
        }
        return false;
    }
}
