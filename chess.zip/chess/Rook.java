import java.util.Map;

/**
 * rook piece
 * @author Tingcheng Pan
 */
public class Rook extends Piece{

    /**
     * constructor
     * @param camp chess's camp
     * @param x the horizontal axis location
     * @param y the vertical axis location
     */
    public Rook(String camp, int x, int y) {
        super(camp, "R", x, y);
    }

    @Override
    boolean canMove(int moveToX, int moveToY, Map<String, Piece> pieceMap) {
        if (this.x == moveToX) {
            if (this.y > moveToY) {
                for (int i = y - 1; i >= moveToY; i--) {
                    Piece piece = pieceMap.get(x + "_" + i);
                    if (piece == null) {
                        continue;
                    }
                    if (i == moveToY && !this.camp.equals(piece.camp)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            } else {
                for (int i = y + 1; i <= moveToY; i++) {
                    Piece piece = pieceMap.get(x + "_" + i);
                    if (piece == null) {
                        continue;
                    }
                    if (i == moveToY && !this.camp.equals(piece.camp)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        } else if (this.y == moveToY) {
            if (this.x > moveToX) {
                for (int i = x - 1; i >= moveToX; i--) {
                    Piece piece = pieceMap.get(i + "_" + y);
                    if (piece == null) {
                        continue;
                    }
                    if (i == moveToX && !this.camp.equals(piece.camp)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            } else {
                for (int i = x + 1; i <= moveToX; i++) {
                    Piece piece = pieceMap.get(i + "_" + y);
                    if (piece == null) {
                        continue;
                    }
                    if (i == moveToX && !this.camp.equals(piece.camp)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }
        return true;
    }
}
